# LaTeX2HTML 2002-2-1 (1.70)
# Associate images original text with physical files.


$key = q/n;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="$n$">|; 

$key = q/(LINUX_SRC);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="106" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\(LINUX\_SRC\)">|; 

1;

