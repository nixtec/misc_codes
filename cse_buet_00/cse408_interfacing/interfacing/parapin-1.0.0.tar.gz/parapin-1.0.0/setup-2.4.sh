#!/bin/sh

cp -i Makefile-2.4 Makefile

