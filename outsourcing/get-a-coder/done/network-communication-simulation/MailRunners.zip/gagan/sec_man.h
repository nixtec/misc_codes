/*
 * sec_man.h
 * @uthor: Gagandeep Jaswal
 * Security Manager header file
 */
#ifndef _SEC_MAN_H_
#define _SEC_MAN_H_

int validateCredential(const char *user, const char *pass);

#endif
