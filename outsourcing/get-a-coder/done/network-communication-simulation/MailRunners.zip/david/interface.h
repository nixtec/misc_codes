// David

void printHeader();
void printMainScreen();
void printFooter();
void printMailOptions();
void printFolderList();
void printFolderOptions();
void clear();
