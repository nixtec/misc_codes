/*
 * myregex.c
 */
#include "myregex.h"

