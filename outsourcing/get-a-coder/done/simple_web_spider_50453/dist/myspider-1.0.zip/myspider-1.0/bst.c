/*
 * bst.c
 */
#include "bst.h"

/* binary search tree functions */
tree_t tree_destroy(tree_t t, bool free_element)
{
  if (t) {
    tree_destroy(t->left, free_element);
    tree_destroy(t->right, free_element);
    if (free_element == true) {
      free(t->e);
    }
    free(t);
  }
  return NULL;
}

tpos_t tree_find(tree_t t, telement_t e, int (*compfunc)(void *, void *))
{
  int result = 0;

  if (!t)
    return NULL;

  result = compfunc(e, t->e);
  if (result < 0)
    return tree_find(t->left, e, compfunc);
  if (result > 0)
    return tree_find(t->right, e, compfunc);

  /* else */
  return t;
}

tpos_t tree_find_min(tree_t t)
{
  if (!t)
    return NULL;

  if (!t->left)
    return t;

  return tree_find_min(t->left);
}

tpos_t tree_find_max(tree_t t)
{
  if (!t) {
    while (t->right) {
      t = t->right;
    }
  }

  return t;
}

tree_t tree_insert(tree_t t, telement_t e, int (*compfunc)(void *, void *))
{
  int result = 0;

  if (!t) {
    /* create one-node tree */
    t = malloc(sizeof(tnode_t));
    if (!t) {
      perror("malloc");
      exit(1); /* we can't progress, no memory available */
    } else {
      t->e = e;
      t->left = t->right = NULL;
    }
  } else {
    result = compfunc(e, t->e);
    if (result < 0) {
      t->left = tree_insert(t->left, e, compfunc);
    } else if (result > 0) {
      t->right = tree_insert(t->right, e, compfunc);
    } else {
      /* otherwise element is in the tree, do nothing, error */
      fprintf(stderr, "*** ERROR: Existing node\n");
    }
  }

  return t;
}

tree_t tree_delete(tree_t t, telement_t e, int (*compfunc)(void *, void *),
    bool free_element)
{
  int result = 0;
  tpos_t tmp;

  if (!t) {
    fprintf(stderr, "Tree empty!\n");
  } else {
    result = compfunc(e, t->e);

    if (result < 0) { /* go left */
      t->left = tree_delete(t->left, e, compfunc, free_element);
    } else if (result > 0) { /* go right */
      t->right = tree_delete(t->right, e, compfunc, free_element);
    } else { /* found element */
      if (t->left && t->right) { /* both children exist */
	tmp = tree_find_min(t->right);
	t->e = tmp->e;
	t->right = tree_delete(t->right, t->e, compfunc, free_element);
      } else { /* one or zero children */
	tmp = t;
	if (!t->left) {
	  t = t->right;
	} else if (!t->right) {
	  t = t->left;
	}
	if (free_element == true) {
	  free(tmp->e);
	}
	free(tmp);
      }
    }
  }

  return t;
}

/* we have macro for these, so functions are not needed */
#if 0
element_t tree_get_element(tpos_t p)
{
  if (p) {
    return p->e;
  }
  return NULL;
}
#endif

