/*
 * queue.h
 */
#ifndef QUEUE_H
#define QUEUE_H

#include <stdio.h>
#include "list.h"

/* queue implemented with Linked List */
struct queue_struct {
  lpos_t front;
  lpos_t rear;
};
typedef struct queue_struct queue_t;

lpos_t qinsert(queue_t *q, lelement_t e);
lelement_t qdelete(queue_t *q);
#define qextract qdelete
void qdestroy(queue_t *q, bool free_element);
size_t qlength(queue_t *q);

#endif /* !QUEUE_H */
