/*
 * proc-none.c
 */
#include "server-funcs.h"

#if defined(USE_WORDEXP_H)
#include <wordexp.h>
#elif defined(__CYGWIN__)
#include <glob.h>
#endif

int do_delete_file(int connfd, const char *path);
int do_list_file(int connfd, const char *path);
int do_create_folder(int connfd, const char *path);
int do_delete_folder(int connfd, const char *path);
int do_change_folder(int connfd, const char *path);
int do_pwd(int connfd);

/* 500 means success */
/* please read error-codes.txt for values used in protocol */

/* please read 'protocol.txt' for understanding the protocol used */
/* handle NONE [see protocol.txt for it] */

/* -------------------------------------------------------------------------
 * PROC_NONE
 * -------------------------------------------------------------------------
 *
 */

int proc_none(int connfd, const char *buf)
{
   //  int fd = -1;
   int ret = -1;
   size_t n = -1;
   size_t len = -1;
   //  mode_t mode = 00644;
   char comd[10] = {};
   char path[PATH_MAX] = {};
   char buffer[128] = {};

   /* LIST|DEL|MKDIR|RMDIR|CHDIR path */
   sscanf(buf, "%s", comd);
   /* check 'comd' here whether it is allowed command */
   len = strlen(comd);
   len++; /* skip the space */
   n = strcspn(buf+len, DELIM);
   strncpy(path, buf+len, n);
   path[n] = '\0';
   printf("<%s:%d> comd=<%s>, path=<%s>\n", __FILE__, __LINE__, comd, path);

   sprintf(buffer, "500 OK\n"); /* command supported */
   n = strlen(buffer);
   ret = sendn(connfd, buffer, n);
   if (ret < n) {
      DEBUG("sendn", errno);
      goto cleanup;
   }

   if (!strcmp(comd, "DEL")) {
      ret = do_delete_file(connfd, path);
   } else if (!strcmp(comd, "LIST")) {
      ret = do_list_file(connfd, path);
   } else if (!strcmp(comd, "MKDIR")) {
      ret = do_create_folder(connfd, path);
   } else if (!strcmp(comd, "RMDIR")) {
      ret = do_delete_folder(connfd, path);
   } else if (!strcmp(comd, "CHDIR")) {
      ret = do_change_folder(connfd, path);
   } else if (!strcmp(comd, "GETCWD")) {
      ret = do_getcwd(connfd);
   }

  ret = 0;

cleanup:
  return ret;
}

#ifdef USE_WORDEXP_H
/* -------------------------------------------------------------------------
 * DO_DELETE_FILE
 * -------------------------------------------------------------------------
 *
 */

int do_delete_file(int connfd, const char *path)
{
//  fprintf(stderr, "%s entered\n", __func__);

   int n = -1;
   char buffer[128] = {};
   int ret = -1;
   int fd = -1;
   struct stat statbuf;

   wordexp_t p;
   
   char **w;
   int i = -1;
   
   wordexp(path, &p, 0);
   w = p.we_wordv;

   for (i = 0; i < p.we_wordc; i++) 
   {
      if ((fd = open(w[i], O_RDONLY)) == -1) {
         perror("open");
         sprintf(buffer, "server: open: %s\n", strerror(errno));
         sendn(connfd, buffer, strlen(buffer));
         ret = -1;
         goto cleanup;
      }
   
      if (flock(fd, LOCK_EX) == -1) // exclusive [write] lock
      { // error
         perror("flock");
         sprintf(buffer, "server: flock: %s\n", strerror(errno));
         sendn(connfd, buffer, strlen(buffer));         
         ret = -1;
         goto cleanup;
      }
   
      if (stat(w[i], &statbuf) != 0) 
      {
         flock(fd, LOCK_UN);  // unlock the file
         sprintf(buffer, "server: %s: File removed from another user\n", w[i]);
         n = strlen(buffer);
         ret = sendn(connfd, buffer, n);
         if (ret < n) 
         {
            DEBUG("sendn", errno);
         }
         ret = -1;
         goto cleanup;
      }
   //    printf("Deleting %s ...", w[i]);
      if ((ret = remove(w[i])) != 0) 
      {
         perror(w[i]);
         sprintf(buffer, "server: %s: %s\n", w[i], strerror(errno));
         n = strlen(buffer);
         ret = sendn(connfd, buffer, n);
         if (ret < n) 
         {
            flock(fd, LOCK_UN);  // unlock the file
            DEBUG("sendn", errno);
            goto cleanup;
         }
      }

      flock(fd, LOCK_UN);         // unlock the file

      close(fd);
   }
   
cleanup:
   if(fd > 0)
      close(fd);
   wordfree(&p);
   
   return ret;
   }
#endif

#ifdef USE_WORDEXP_H
/* you will find an example code segment in 'man 3 wordexp' manpage */

/* -------------------------------------------------------------------------
 * DO_LIST_FILE
 * -------------------------------------------------------------------------
 *
 */

int do_list_file(int connfd, const char *path)
{
   //  fprintf(stderr, "%s entered\n", __func__);
   int ret = -1;
   wordexp_t p;
   char **w;
   int i = -1;
   int n = -1;
   
   char buffer[128];
   
   struct stat sstat;
   struct tm stm;
   char timebuf[32];
   
   struct passwd *pw;
   struct group *gr;
   char usr[40];
   char grp[40];
   
   int have_slash = 0;

   if (strrchr(path, '/') == NULL) 
      have_slash = 0;
   else 
      have_slash = 1;
   
   
   ret = wordexp(path, &p, 0);
   if (ret != 0) {
      perror("wordexp");
      return -1;
   }

   memset(timebuf, 0, sizeof(timebuf));
   memset(usr, 0, sizeof(usr));
   memset(grp, 0, sizeof(grp));

  /* matched strings are saved in p.we_wordv, p.we_wordc contains count */
   w = p.we_wordv;
   for (i = 0; i < p.we_wordc; i++) 
   {
      if (stat(w[i], &sstat) != 0) 
      {
         sprintf(buffer, "server: %s: %s\n", w[i], strerror(errno));
         n = strlen(buffer);
         ret = sendn(connfd, buffer, n);
         if (ret < n) 
         {
            DEBUG("sendn", errno);
            goto cleanup;
         }
         perror(w[i]);
      } 
      else 
      {
         /* hold a lock to read the password entry, this is to save some memory */
         pthread_mutex_lock(&pwlock);

         pw = getpwuid(sstat.st_uid);
         if (!pw) 
         { /* no such user */
            sprintf(usr, "%d", sstat.st_uid);
         } 
         else 
         {
         strncpy(usr, pw->pw_name, sizeof(usr)-1);
         }

         gr = getgrgid(sstat.st_gid);

         if (!gr) 
         { /* no such group */
            sprintf(grp, "%d", sstat.st_gid);
         } 
         else {
            strncpy(grp, gr->gr_name, sizeof(grp)-1);
         }
         pthread_mutex_unlock(&pwlock);

         localtime_r(&sstat.st_atime, &stm); // use access time
         //localtime_r(&sstat.st_mtime, &stm); // use modification time
         //strftime(timebuf, sizeof(timebuf)-1, "%a %b %d %T %Y", &stm);
         //
         // Feb 14 02:14
         strftime(timebuf, sizeof(timebuf)-1, "%b %d %R", &stm);
         /* %c is not working in my Windows, so using the above format */
   //      strftime(timebuf, sizeof(timebuf)-1, "%c ", &stm);
         sprintf(buffer, "%c" // file type d or -
            "%c%c%c" // owner permission
            "%c%c%c" // group permission
            "%c%c%c" // other permission
            " %d" // number of hard links
            //" %d %d" // uid gid
            " %8s %8s" // user group
            " %10d" // size
            " %s" // modification time
            " %s" // filename
            "\n",
            S_ISDIR(sstat.st_mode) ? 'd' : '-',
            /* owner permission */
            ((sstat.st_mode & S_IRWXU) & S_IRUSR) ? 'r' : '-',
            ((sstat.st_mode & S_IRWXU) & S_IWUSR) ? 'w' : '-',
            ((sstat.st_mode & S_IRWXU) & S_IXUSR) ? 'x' : '-',
            /* group permission */
            ((sstat.st_mode & S_IRWXG) & S_IRGRP) ? 'r' : '-',
            ((sstat.st_mode & S_IRWXG) & S_IWGRP) ? 'w' : '-',
            ((sstat.st_mode & S_IRWXG) & S_IXGRP) ? 'x' : '-',
            /* others permission */
            ((sstat.st_mode & S_IRWXO) & S_IROTH) ? 'r' : '-',
            ((sstat.st_mode & S_IRWXO) & S_IWOTH) ? 'w' : '-',
            ((sstat.st_mode & S_IRWXO) & S_IXOTH) ? 'x' : '-',
            /* number of hard links */
            sstat.st_nlink,
            //sstat.st_uid, sstat.st_gid,
            usr, grp,
            (int) sstat.st_size,
            timebuf,
            have_slash ? strrchr(w[i], '/')+1 : w[i]
            );
            //"%10d\t%s\t%s\n", (int) sstat.st_size, timebuf,
            //have_slash ? strrchr(w[i], '/')+1 : w[i]);
         /*
         sprintf(buffer, "%10d\t%s\t%s\n", (int) sstat.st_size, timebuf,
            have_slash ? strrchr(w[i], '/')+1 : w[i]);
            */
         n = strlen(buffer);
         ret = sendn(connfd, buffer, n);
         if (ret < n) 
         {
            DEBUG("sendn", errno);
            goto cleanup;
         }
      //      printf("%10d\t%s\t%s\n", (int) sstat.st_size, timebuf, w[i]);
      }
   }

cleanup:

  wordfree(&p);
  return ret;
}
#endif


#ifdef USE_GLOB_H
/* you will find an example code segment in 'man 3 glob' manpage */

/* -------------------------------------------------------------------------
 * DO_DELETE_FILE
 * -------------------------------------------------------------------------
 *
 */

int do_delete_file(int connfd, const char *path)
{
   glob_t globbuf;
   char **w;
   int ret = -1;
   int i = -1;
   int n = -1;
   
   char buffer[128] = {};
   
   ret = glob(path, 0, NULL, &globbuf);
   if (ret != 0)
      return -1;
   
   /* matched strings are saved in gl_pathv, gl_pathc contains count */
   w = globbuf.gl_pathv;
   for (i = 0; i < globbuf.gl_pathc; i++) 
   {
   //    printf("Deleting %s ...", w[i]);
      if ((ret = remove(w[i])) != 0) 
      {
         perror(w[i]);
         sprintf(buffer, "server: %s: %s\n", w[i], strerror(errno));
         n = strlen(buffer);
         ret = sendn(connfd, buffer, n);
         if (ret < n) 
         {
            DEBUG("sendn", errno);
            goto cleanup;
         }
      }
   }

cleanup:

   globfree(&globbuf);
   return ret;
}
#endif

#ifdef USE_GLOB_H
/* list files and sends listing to client */

/* -------------------------------------------------------------------------
 * DO_LIST_FILE
 * -------------------------------------------------------------------------
 *
 */

int do_list_file(int connfd, const char *path)
{
//  fprintf(stderr, "%s entered\n", __func__);
   int ret = -1;
   
   glob_t globbuf;
   char **w;
   int i = -1;
   int n = -1;
   
   char buffer[128] = {};
   
   struct stat sstat;
   struct tm stm;
   char timebuf[32] = {};
   
   int have_slash = 0;
   
   if (strrchr(path, '/') == NULL) 
   {
      have_slash = 0;
   } 
   else 
   {
      have_slash = 1;
   }
   
   ret = glob(path, 0, NULL, &globbuf);
   if (ret != 0) 
   {
      perror("glob");
      return -1;
   }
   
   memset(timebuf, 0, sizeof(timebuf));
   
   w = globbuf.gl_pathv;
   for (i = 0; i < globbuf.gl_pathc; i++) 
   {
      if (stat(w[i], &sstat) != 0) 
      {
         perror(w[i]);
         sprintf(buffer, "server: %s: %s\n", w[i], strerror(errno));
         n = strlen(buffer);
         ret = sendn(connfd, buffer, n);
         if (ret < n) 
         {
            DEBUG("sendn", errno);
            goto cleanup;
         }
      } 
      else 
      {
         /* size last_access filename */
         localtime_r(&sstat.st_atime, &stm);
         strftime(timebuf, sizeof(timebuf)-1, "%a %b %d %T %Y", &stm);
         //strftime(timebuf, sizeof(timebuf)-1, "%c ", &stm);
         sprintf(buffer, "%10d\t%s\t%s\n", (int) sstat.st_size, timebuf,
            have_slash ? strrchr(w[i], '/')+1 : w[i]);
         n = strlen(buffer);
         ret = sendn(connfd, buffer, n);
         if (ret < n) 
         {
            DEBUG("sendn", errno);
            goto cleanup;
         }
   //      printf("%10d\t%s\t%s\n", (int) sstat.st_size, timebuf, w[i]);
      }
   }

cleanup:
  globfree(&globbuf);

  return ret;
}
#endif

/* reimplement using Win32 APIs */

/* create folder locally */

/* -------------------------------------------------------------------------
 * DO_CREATE_FOLDER
 * -------------------------------------------------------------------------
 *
 */

int do_create_folder(int connfd, const char *path)
{
   //  fprintf(stderr, "%s entered\n", __func__);
   
   int n = -1;
   char buffer[128] = {};
   int ret = -1;
   //  mode_t mode = 00755;

   ret = mkdir(path, 00755);
   if (ret != 0) 
   {
      sprintf(buffer, "server: %s: %s\n", path, strerror(errno));
      n = strlen(buffer);
      ret = sendn(connfd, buffer, n);
      if (ret < n)
         DEBUG("sendn", errno);
   }
   
   return ret;
}

/* delete folder locally */

/* -------------------------------------------------------------------------
 * DO_DELETE_FOLDER
 * -------------------------------------------------------------------------
 *
 */

int do_delete_folder(int connfd, const char *path)
{
   //  fprintf(stderr, "%s entered\n", __func__);
   
   int n = -1;
   char buffer[128] = {};
   int ret = -1;
   int fd = -1;

   ret = rmdir(path);
   if (ret != 0) 
   {
      perror("rmdir");
      sprintf(buffer, "server: %s: %s\n", path, strerror(errno));
      n = strlen(buffer);
      ret = sendn(connfd, buffer, n);
      if (ret < n)
         DEBUG("sendn", errno);
   }


   return ret;
}

/* chdir() call is not thread-safe. To get around this problem, clients will
 * tell their directory they know the server will use as current directory
 * for that client. To service the client, server will first change to that
 * directory after holding a mutex and will change back to the old directory
 * after doing the thing.
 */
/* does 'chdir()' locally */

/* -------------------------------------------------------------------------
 * DO_CHANGE_FOLDER
 * -------------------------------------------------------------------------
 *
 */

int do_change_folder(int connfd, const char *path)
{
   //  fprintf(stderr, "%s entered\n", __func__);
   
   int n = -1;
   char buffer[PATH_MAX+128] = {};
   char pwd[PATH_MAX+1] = {};
   int ret = -1;
   
   ret = chdir(path);
   if (ret != 0) 
   {
      sprintf(buffer, "server: %s: %s\n", path, strerror(errno));
      n = strlen(buffer);
      ret = sendn(connfd, buffer, n);
      if (ret < n)
         DEBUG("sendn", errno);
   } 
   else 
   {
      pwd[PATH_MAX] = 0;
      sprintf(buffer, "Directory changed to '%s'\n", getcwd(pwd, sizeof(pwd)));
      n = strlen(buffer);
      ret = sendn(connfd, buffer, n);
      if (ret < n)
         DEBUG("sendn", errno);
   }
   
   return ret;
}

/* gets current working directory */

/* -------------------------------------------------------------------------
 * DO_GETCWD
 * -------------------------------------------------------------------------
 *
 */

int do_getcwd(int connfd)
{
   //  fprintf(stderr, "%s entered\n", __func__);
   
   int n = -1;
   char buffer[PATH_MAX+128] = {};
   char pwd[PATH_MAX+1] = {};
   int ret = -1;
   
   pwd[PATH_MAX] = 0;
   sprintf(buffer, "%s\n", getcwd(pwd, sizeof(pwd)));
   n = strlen(buffer);
   ret = sendn(connfd, buffer, n);
   if (ret < n)
      DEBUG("sendn", errno);
   
   return ret;
}
