/*
 * proc-move.c 
 */
#include "server-funcs.h"

/* 500 means success */
/* please read error-codes.txt for values used in protocol */

/* please read 'protocol.txt' for understanding the protocol used */
/* handle 'move' */

static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

/* -------------------------------------------------------------------------
 * PROC_MOVE
 * -------------------------------------------------------------------------
 *
 */
 
int proc_move(int connfd, const char *buf)
{
   //  int fd = -1;
   int ret = -1;
   size_t n = -1;
   size_t len = -1;
   int fd1 = -1;
   int fd2 = -1;
   //  mode_t mode = 00644;
   char comd[10] = {};
   char src[PATH_MAX] = {};
   char dst[PATH_MAX] = {};
   char buffer[128] = {};

//  sscanf(buf, "%s%s%s", comd, src, dst);

  /* MOVE file1:file2 */
   sscanf(buf, "%s", comd);     /* comd = COPY|MOVE */
   len = strlen(comd);
   len++;                       /* skip the <space> */
   
//  len = strlen(buf);
   n = strcspn(buf+len, DELIM); /* DELIM is #define'd in common.h */
   strncpy(src, buf+len, n);    /* source retrieved */
   src[n++] = '\0';             /* n++ will skip the DELIM */
   len += n;
   n = strcspn(buf+len, DELIM); /* DELIM is #define'd in common.h */
   strncpy(dst, buf+len, n);    /* destination retrieved */
   dst[n] = '\0'; 
   printf("<%s:%d> src=<%s> dst=<%s>\n", __FILE__, __LINE__, src, dst);

   if (access(src, F_OK) != 0) 
   { // file exists
      fprintf(stderr, "Input file not exists\n");
      sprintf(buffer, "server: Input file not exists\n");
      n = strlen(buffer);
      ret = sendn(connfd, buffer, n);
      return 0; // don't proceed
   }
   
   if ((fd1 = open(src, O_RDONLY)) < 0) 
   {
      perror("open");
      sprintf(buffer, "server: open: %s\n", strerror(errno));
      ret = sendn(connfd, buffer, strlen(buffer));
      return 0; // don't proceed
   }
   
   if (!strcmp(comd, "COPY")) 
      ret = flock(fd1, LOCK_SH); /* get shared [read] lock */
   else
      ret = flock(fd1, LOCK_EX); /* get exclusive [write] lock */
   
   if (access(src, F_OK) != 0) 
   { // file exists
      fprintf(stderr, "File is removed before the processing of the request\n");
      sprintf(buffer, "server: File is removed before the processing of your request\n");
      flock(fd1, LOCK_UN);  /* unlock the file */
      n = strlen(buffer);
      ret = sendn(connfd, buffer, n);
      ret = 0; // don't proceed
      goto cleanup;
   }
   
   /* to prevent race condition hold the mutex here */
   pthread_mutex_lock(&mutex);
   
   if (access(dst, F_OK) == 0) 
   { // file exists
      fprintf(stderr, "Output file already exists\n");
      sprintf(buffer, "server: Output file already exists\n");
      flock(fd1, LOCK_UN);  /* unlock the file */
      pthread_mutex_unlock(&mutex);
      n = strlen(buffer);
      ret = sendn(connfd, buffer, n);
      ret = 0; // don't proceed
      goto cleanup;
   }

  /* create file for writing */
   if ((fd2 = open(dst, O_CREAT|O_TRUNC|O_WRONLY, 00644)) < 0) 
   {
      perror("open");
      sprintf(buffer, "server: open: %s\n", strerror(errno));
      sendn(connfd, buffer, strlen(buffer));
      flock(fd1, LOCK_UN);  /* unlock the file */
      pthread_mutex_unlock(&mutex);
      ret = 0; // don't proceed
      goto cleanup;
   }

   ret = flock(fd2, LOCK_EX); /* get exclusive [write] lock */

   if (ret == -1) 
   { // error
      perror("flock");
      sprintf(buffer, "400 ERROR server: flock: %s\n", strerror(errno));
      sendn(connfd, buffer, strlen(buffer));
      flock(fd1, LOCK_UN);  /* unlock the file */
      flock(fd2, LOCK_UN);  /* unlock the file */
      pthread_mutex_unlock(&mutex);
      goto cleanup;
   }

   /* file is now created and the creator thread have an  EX_lock on it, 
    * other threads will now see the file by access(), and wait a lock on it */
   /* so we can unlock the mutex here */
   pthread_mutex_unlock(&mutex);

   sprintf(buffer, "500 OK\n"); /* command supported */
   n = strlen(buffer);
   ret = sendn(connfd, buffer, n);
   
   if (ret < n) 
   {
      DEBUG("sendn", errno);
      goto cleanup;
   }

   if (!strcmp(comd, "COPY")) 
   {
      ret = do_local_copy(fd1, fd2);
      if (ret != 0) 
      {
         sprintf(buffer, "server: %s\n", strerror(ret));
         flock(fd1, LOCK_UN);  /* unlock the file */
         flock(fd2, LOCK_UN);  /* unlock the file */
         n = strlen(buffer);
         ret = sendn(connfd, buffer, n);
         if (ret < n) 
         {
            DEBUG("sendn", errno);
            goto cleanup;
         }
      }
   } 
   else 
   { /* MOVE */
      ret = rename(src, dst);
      if (ret == 0)
         goto cleanup;
      
      if (errno == EXDEV) 
      {
         ret = do_local_copy(fd1, fd2);
         if (ret != 0) 
         {
            sprintf(buffer, "server: %s\n", strerror(ret));
            flock(fd1, LOCK_UN);  /* unlock the file */
            flock(fd2, LOCK_UN);  /* unlock the file */
            n = strlen(buffer);
            ret = sendn(connfd, buffer, n);
            if (ret < n) 
            {
               DEBUG("sendn", errno);
               goto cleanup;
            }
         } 
         else 
         {
            flock(fd2, LOCK_UN);  /* unlock the file */
            ret = remove(src); /* remove the src file */
            if (ret != 0) 
            {
               sprintf(buffer, "server: %s\n", strerror(errno));
               flock(fd1, LOCK_UN);  /* unlock the file */
               flock(fd2, LOCK_UN);  /* unlock the file */
               n = strlen(buffer);
               ret = sendn(connfd, buffer, n);
               if (ret < n) 
               {
                  DEBUG("sendn", errno);
                  goto cleanup;
               }
            }
            flock(fd1, LOCK_UN);  /* unlock the file */
         }
      } 
      else 
      {
         sprintf(buffer, "server: %s\n", strerror(errno));
         flock(fd1, LOCK_UN);  /* unlock the file */
         flock(fd2, LOCK_UN);  /* unlock the file */
         n = strlen(buffer);
         ret = sendn(connfd, buffer, n);
         if (ret < n) 
         {
            DEBUG("sendn", errno);
            goto cleanup;
         }
      }
   }

   ret = 0;
   
cleanup:
   if(fd1 > 0)
      close(fd1);
   if(fd2 > 0)
      close(fd2);
   return ret;
}

/* -------------------------------------------------------------------------
 * DO_LOCAL_COPY
 * -------------------------------------------------------------------------
 *
 */

int do_local_copy(const int fd1, const int fd2)
{
   //  fprintf(stderr, "%s entered\n", __func__);
   
   int ret = -1;
   ssize_t nread = -1;
   char buf[1024] = {};
   
   while ((nread = read(fd1, buf, sizeof(buf))) > 0) 
   {
      ret = write(fd2, buf, nread);
      if (ret < nread) 
      {
         perror("write");
         ret = -3;
         goto cleanup;
      }
   }
   
   ret = 0;
   
cleanup:
   close(fd1);
   close(fd2);
   
   return ret;
}
