/*
 * authenticate.h
 */
#ifndef AUTHENTICATE_H
#define AUTHENTICATE_H

#include <stdio.h>
#include <stdlib.h>

/* PAM routines */
#include <security/pam_appl.h>
#include <security/pam_misc.h>

#include <pwd.h>		/* /etc/passwd file routines */
#include <sys/types.h>
#include <unistd.h>

int authenticate(int fd, const char *user, const char *svc);

#endif
