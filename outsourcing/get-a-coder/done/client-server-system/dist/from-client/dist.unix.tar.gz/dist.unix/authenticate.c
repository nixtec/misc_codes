/*
 * authenticate.c
 */
#include "authenticate.h"

/*
 * to understand this file you may need to read
 * http://www.kernel.org/pub/linux/libs/pam/Linux-PAM-html/
 * http://www.kernel.org/pub/linux/libs/pam/Linux-PAM-html/Linux-PAM_ADG.html
 */

/* the tricky part was to make it work over the socket connection */

/* pam conversation structure */

static struct pam_conv conv = {
   misc_conv,
   NULL
};

/* -----------------------------------------------------------------------
 * WHAT_ERROR
 * -----------------------------------------------------------------------
 */

static void what_error(pam_handle_t *pamh,const char *fn, int code)
{
   fprintf(stderr,"==> called %s()\n  got: `%s'\n", fn, pam_strerror(pamh, code));
}

/* -----------------------------------------------------------------------
 * AUTHENTICATE
 * -----------------------------------------------------------------------
 */

int authenticate(int fd, const char *user, const char *svc)
{
   pam_handle_t *pamh = NULL;
   const char *username = user;
   const char *service = svc;
   int retcode = -1;
   int success = -1;
   
   char buffer[100] = {};
   
   if (!username)
      return -1;
   if (!service)
      return -2;

   /* initialize the Linux-PAM library */
   retcode = pam_start(service, username, &conv, &pamh);
   if (retcode != PAM_SUCCESS) 
   {
      what_error(pamh, "pam_start", retcode);
      return -3;
   }

   retcode = gethostname(buffer, sizeof(buffer)-1);
   if (retcode) 
   {
      perror("failed to look up hostname");
      goto cleanup;
   }
   retcode = pam_set_item(pamh, PAM_RHOST, buffer);
   //  what_error(pamh, "pam_set_item(PAM_RHOST)", retcode);
   
   /*
   retcode = ttyname_r(fileno(stdin), buffer, sizeof(buffer)-1);
   if (retcode) {
      fprintf(stderr, "ttyname_r: %s\n", strerror(retcode));
   } else {
      retcode = pam_set_item(pamh, PAM_TTY, buffer);
      what_error(pamh, "pam_set_item(PAM_TTY)", retcode);
   }
   */

   /* has the user proved themself valid? */
   retcode = pam_authenticate(pamh, 0);
   if (retcode != PAM_SUCCESS) 
   {
      what_error(pamh, "pam_authenticate", retcode);
      success = -4;
      fprintf(stderr,"%s: invalid request\n", pam_strerror(pamh, retcode));
   } 
   else 
   {
      success = 0;
   }

cleanup:
   /* close the Linux-PAM library */
   retcode = pam_end(pamh, PAM_SUCCESS);
   //  what_error(pamh, "pam_end", retcode);
   pamh = NULL;
   
   if (success == 0)
      retcode = 0;
   else
      retcode = 1;
   
   return retcode;
}
