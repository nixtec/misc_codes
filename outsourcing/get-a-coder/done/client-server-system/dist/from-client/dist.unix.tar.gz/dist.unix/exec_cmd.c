/*
 * exec_cmd.c
 */
#include "exec_cmd.h"

#define MAX(a, b) (((a) > (b)) ? (a) : (b))

/* -----------------------------------------------------------------------
 * EXEC_CMD
 * -----------------------------------------------------------------------
 */

void exec_cmd(int connfd, const char *shell, const char *arg, const char *cmd, uid_t uid)
{
   const char *cp = NULL;
   pid_t pid;
   int status = 0;
   int n = -1;
   
   int p[2][2];

  // kernel maintains select() per process basis
   if ((pid = fork()) == 0) 
   {
      pipe(p[0]); /* parent -> child */
      pipe(p[1]); /* child -> parent */

      switch(pid = fork()) 
      {
         case -1:
         perror("fork");
         return;
         break;
         case 0:
#ifdef linux
            if (geteuid() == 0) 
            { // root
               if (setuid(uid)) 
               { // run as user uid
                  perror("setuid");
                  exit(1); // not safe to execute
               }
            }
#endif
            close(connfd);
            close(p[0][1]);
            close(p[1][0]);
            dup2(p[0][0], STDIN_FILENO);
            dup2(p[1][1], STDOUT_FILENO);
            dup2(p[1][1], STDERR_FILENO);
            cp = strrchr(shell, DIR_DELIM);
            if (cp)
               cp++;
            else
               cp = shell;
            execl(shell, cp, arg, cmd, NULL);
            exit(2); // never reach here if successfully executed
            break;

         default:
            break;
      }

      /* only parent will reach here */
      close(p[0][0]);
      close(p[1][1]);
   
      int maxfdp1 = 0;
      fd_set rset;
      char buf[256] = {};
   
      FD_ZERO(&rset);
   
      while (1) 
      {
         FD_SET(connfd, &rset);
         FD_SET(p[1][0], &rset);
         maxfdp1 = MAX(p[1][0], connfd) + 1;
   
         if (select(maxfdp1, &rset, NULL, NULL, NULL) == -1) 
         {
            perror("select");
         }
   
         if (FD_ISSET(connfd, &rset)) 
         { // socket is readable
            n = recv(connfd, buf, sizeof(buf), 0);
            if (n <= 0) 
            { // socket error or closed
               break;
            }
            n = write(p[0][1], buf, n);
            if (n < 0) 
            {
               perror("write");
               break;
            }
         }
   
         if (FD_ISSET(p[1][0], &rset)) 
         {
            n = read(p[1][0], buf, sizeof(buf));
            if (n <= 0) 
            {
               //perror("read");
               break;
            }
            n = sendn(connfd, buf, n);
            if (n < 0) 
            {
               perror("send");
            }
         }
      }
   
      /* we're done with pipe */
      close(p[0][1]);
      close(p[1][0]);
   
      if (waitpid(pid, &status, 0) != pid) 
      {
         perror("waitpid");
      }
   
      exit(0);
   } 
   else if (pid != -1) 
      waitpid(pid, &status, 0);
}
