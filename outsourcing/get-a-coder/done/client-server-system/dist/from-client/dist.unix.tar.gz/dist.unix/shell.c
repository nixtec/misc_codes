/*
 * shell.c
 * main file for client
 */
#include <stdio.h>
#include "functions.h"
#include "parser.h"		/* command line parser */
#include "config.h"		/* common between client and server */

#define NONE		0
#define LOCAL		1
#define UPLOAD		2
#define DOWNLOAD	3
#define MOVE		4

#define FALSE		0
#define TRUE 		1

/* convert / and \ accordingly so that any notation can be used */
static void fix_path(char *path, size_t len)
{
   int i;
   
   for (i = 0; i < len; i++) {
      if (path[i] == '\\') path[i] = '/';
   }
}


int do_copy(
    const char *srcaddr,
    const char *src,
    const char *dstaddr,
    const char *dst,
    int del);                  /* del = 1 true | 0 false */

int do_delete(
    const char *dstaddr,       /* server */
    const char *path);         /* filename/pattern */

int do_list(
    const char *dstaddr,       /* server */
    const char *path);         /* filename/pattern */

int do_create_folder(
    const char *dstaddr,       /* server */
    const char *path);         /* filename/pattern */

int do_delete_folder(
    const char *dstaddr,       /* server */
    const char *path);         /* filename/pattern */

int do_change_folder(
    const char *dstaddr,       /* server */
    const char *path);         /* filename/pattern */

int do_get_current_dir(const char *srcaddr);

int do_handle_execute(const char *srcaddr, const char *src);

void prompt(void);

/* client is single threaded, so we can simply use globals here */
char cmdbuf[1024];
int cmdbufsize = sizeof(cmdbuf);
char redir_in[PATH_MAX+1];
int redir_in_size = sizeof(redir_in);
char redir_out[PATH_MAX+1];
int redir_out_size = sizeof(redir_out);

int main(int argc, char **argv)
{
   char buf[256];
   int del;
   
   char command[32];
   char src[256], dst[256];
   char srcaddr[128], dstaddr[128];
   
   prompt();
   while (fgets(buf, sizeof(buf), stdin)) 
   {
//    len = strlen(buf);
//    buf[len-1] = 0; /* remove newline */
//    strcpy(tmpbuf, buf); /* save for execute command */

      fix_path(buf, strlen(buf));
   
      command[0] = srcaddr[0] = src[0] = dstaddr[0] = dst[0] = redir_in[0]
         = redir_out[0] = 0; /* initialize, so that we don't get mixed with
			     old values */
      /* parse command line and fill the appropriate buffers */
      if (parse_command_line(buf, command, srcaddr, src, dstaddr, dst,
            redir_in, redir_out) != 0) 
      {
         fprintf(stderr, "Parse error\n");
         prompt();
         continue;
      }
    /*
    if (redir_in[0] != '\0') {
      fprintf(stderr, "redir_in = %s\n", redir_in);
    }
    if (redir_out[0] != '\0') {
      fprintf(stderr, "redir_out = %s\n", redir_out);
    }
    prompt();
    continue;
    */

      /* now process the commands */
      if (!strcmp(command, "copy")) {
         del = FALSE;
         do_copy(srcaddr, src, dstaddr, dst, del);
      } else if (!strcmp(command, "move")) {
         del = TRUE;
         do_copy(srcaddr, src, dstaddr, dst, del);
      } else if (!strcmp(command, "delete")) {
         do_delete(srcaddr, src);
      } else if (!strcmp(command, "list")) {
         do_list(srcaddr, src);
      } else if (!strcmp(command, "create_folder")) {
         do_create_folder(srcaddr, src);
      } else if (!strcmp(command, "delete_folder")) {
         do_delete_folder(srcaddr, src);
      } else if (!strcmp(command, "change_folder")) {
         do_change_folder(srcaddr, src);
      } else if (!strcmp(command, "pwd")) {
         do_get_current_dir(srcaddr);
      } else if (!strcmp(command, "execute")) {
         do_handle_execute(srcaddr, src);
      } else if (!strcmp(command, "exit")) {
         break;
      } else if (!strcmp(command, "")) {
         // do nothing
      } else {
         fprintf(stderr, "Unknown command: %s\n", command);
      }
      prompt();
   } /* while () */

   printf("Exiting\n");

   return 0;
}

int do_copy(const char *srcaddr, const char *src, const char *dstaddr,
    const char *dst, int del)
{
   int type = NONE; /* type of transfer */
   int ret = -1;
   
   /* copy|move file1 server:file2 */
   if (!srcaddr[0] && dstaddr[0])
      type = UPLOAD;
   /* copy|move server:file1 file2 */
   else if (srcaddr[0] && !dstaddr[0])
      type = DOWNLOAD;
   /* copy|move server:file1 server:file2 */
   else if (srcaddr[0] && dstaddr[0]) 
   {
      if (strcmp(srcaddr, dstaddr)) 
      {
         fprintf(stderr, "src and dst servers must be the same\n");
         return -1;
      }
      type = MOVE; /* ignore dstaddr */
   }
   else
      /* copy|move file1 file2 */
      type = LOCAL; /* local copy */
   
   switch (type) 
   {
      case UPLOAD:
         ret = upload_file(src, dstaddr, dst, del);
         break;
      case DOWNLOAD:
         ret = download_file(srcaddr, src, dst, del);
         break;
      case MOVE:
         ret = move_file(srcaddr, src, dst, del); /* srcaddr = dstaddr */
         break;
      case LOCAL:
         ret = copy_file(src, dst, del); /* local copy */
         break;
      default:
         break;
   }
   
   return ret;
}

/* delete file */
int do_delete(const char *srcaddr, const char *path)
{
   int type = NONE; /* type of transfer */
   int ret = -1;
   
   if (!srcaddr[0])
      type = LOCAL;
   else
      type = NONE;
   
   switch (type) 
   {
      case NONE:
         ret = delete_file(srcaddr, path);
         break;
      case LOCAL:
         ret = delete_local_file(path);
         break;
      default:
         break;
   }
   
   return ret;
}

/* list files */
int do_list(const char *srcaddr, const char *path)
{
   int type = NONE; /* type of transfer */
   int ret = -1;
   
   if (!srcaddr[0])
      type = LOCAL;
   else
      type = NONE;
   
   switch (type) 
   {
      case NONE:
         ret = list_file(srcaddr, path);
         break;
      case LOCAL:
         ret = list_local_file(path);
         break;
      default:
         break;
   }
   
   return ret;
}

/* create folder */
int do_create_folder(const char *srcaddr, const char *path)
{
   int type = NONE; /* type of transfer */
   int ret = -1;
   
   if (!srcaddr[0])
      type = LOCAL;
   else
      type = NONE;
   
   switch (type) 
   {
      case NONE:
         ret = create_folder(srcaddr, path);
         break;
      case LOCAL:
         ret = create_local_folder(path);
         break;
      default:
         break;
   }
   
   return ret;
}

/* delete folder */
int do_delete_folder(const char *srcaddr, const char *path)
{
   int type = NONE; /* type of transfer */
   int ret = -1;
   
   if (!srcaddr[0])
      type = LOCAL;
   else
      type = NONE;
   
   switch (type) 
   {
      case NONE:
         ret = delete_folder(srcaddr, path);
         break;
      case LOCAL:
         ret = delete_local_folder(path);
         break;
      default:
         break;
   }
   
   return ret;
}

/* change_folder */
int do_change_folder(const char *srcaddr, const char *path)
{
   int type = NONE; /* type of transfer */
   int ret = -1;
   
   if (!srcaddr[0])
      type = LOCAL;
   else
      type = NONE;
   
   switch (type) 
   {
      case NONE:
         ret = change_folder(srcaddr, path);
         break;
      case LOCAL:
         ret = change_local_folder(path);
         break;
      default:
         break;
   }
   
   return ret;
}

/* pwd */
int do_get_current_dir(const char *srcaddr)
{
   int type = NONE; /* type of transfer */
   int ret = -1;
   
   if (!srcaddr[0])
      type = LOCAL;
   else
      type = NONE;
   
   switch (type) 
   {
      case NONE:
         ret = get_current_dir(srcaddr);
         break;
      case LOCAL:
         ret = get_local_current_dir();
         break;
      default:
         break;
   }
   
   return ret;
}

/* execute ... */
int do_handle_execute(const char *srcaddr, const char *src)
{
   int ret;
   
   /*
   fprintf(stderr, "server=<%s>, servcmd=<%s>, redirect=<%s>\n",
         server, servcmd, redirect_out);
         */
   
   ret = execute_command(srcaddr, src);
   
   return 0;
}

void prompt(void)
{
   static char pbuf[PATH_MAX+1];
   fprintf(stderr, "%s $ ", strrchr(getcwd(pbuf, sizeof(pbuf)), DIR_DELIM)+1);
   fflush(stderr);
}
