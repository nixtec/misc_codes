#ifndef CONFIG_H
#define CONFIG_H

#define LISTENQ 5		/* maximum queue length for server */
#define MAXLINE 256		/* maximum length of a line (message) */
/* server will listen on this port */
#define SERV_PORT 1234		/* convert it to network byte order */

//#define LOGFILE "/tmp/cs.server.log"	/* server log file [unused] */
#define LOGFILE "cs.server.log"		/* server log file [unused] */

/* arg2 = error_value */
#define DEBUG(arg1,arg2) fprintf(stderr, "<%s:%d> %s: %s. %s\n", __FILE__, \
    __LINE__, __func__, arg1, (arg2) ? strerror(arg2) : "")

#define TRACE_LINE() fprintf(stderr, "<%s:%d> func=%s errno=%d\n", \
    __FILE__, __LINE__, __func__, errno)

/* cygwin may not have PATH_MAX defined */
#ifndef PATH_MAX		/* maximum length of a pathname */
#define PATH_MAX 512
#endif

/* cygwin may not have INET_ADDRSTRLEN defined */
#ifndef INET_ADDRSTRLEN		/* size of ipv4 [dotted quad] address buffer */
#define INET_ADDRSTRLEN 16
#endif

#define DELIM_CHAR '\x2'	// delimiter for parsing request
#define DELIM "\x2\n"		// use same char at the start as DELIM_CHAR

#define DIR_DELIM '/'

#if defined(linux)
#define USE_WORDEXP_H
#define HAVE_INET_NTOP
#elif defined(__CYGWIN__)
#define USE_GLOB_H
#endif

/* syntax of file:
 * CMD:UNIXCMD:WINCMD
 * ListDir:ls:dir
 */
#define CMDMAPFILE "cmdmap.conf"

#endif /* CONFIG_H */
