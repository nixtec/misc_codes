/*
 * proc-exec.c
 */
#include "server-funcs.h"
#include "exec_cmd.h"

#ifdef linux
#include <strings.h>
#include "authenticate.h"
#endif

#ifdef linux
int authenticate_client(int connfd, char *shell, uid_t *uid);
#endif

#ifdef __NO__
int parse_command_line(const char *line, struct cmd **cmdp);
#endif

int fix_command_line(const char *line, char *cmdp);

/* 500 means success */
/* please read error-codes.txt for values used in protocol */

/* please read 'protocol.txt' for understanding the protocol used */
/* handle 'execute' */

#ifdef __WIN32__
#define SHELL "cmd.exe"
#else
#define SHELL "/bin/sh"
#endif

#define MAX_CMDLINE 256
#define CMD_NOSUPPORT -256

/* -------------------------------------------------------------------------
 * PROC_EXEC
 * -------------------------------------------------------------------------
 *
 */

int proc_exec(int connfd, const char *buf)
{
   char shell_path[PATH_MAX+1] = {}; // full path of shell
   //  fprintf(stderr, "<%s>\n", __func__);
   
   int ret = -1;
   int n = -1;
   uid_t uid = 0; // in Windows this will be ignored
   
   char buffer[512] = {};
   
   char cs[MAX_CMDLINE] = {};

#ifdef linux
   uid = getuid();
   if (authenticate_client(connfd, shell_path, &uid) != 0) {
      goto cleanup;
   }
#endif

//  fprintf(stderr, "%s", buf);
   if ((ret = fix_command_line(buf, cs)) >= 0) {
      sprintf(buffer, "500 OK\n"); /* command supported */
      n = strlen(buffer);
      ret = sendn(connfd, buffer, n);
      if (ret < n) 
      {
         perror("sendn");
         goto cleanup;
      }
   } 
   else if (ret == CMD_NOSUPPORT) 
   {
      /* command not supported */
      sprintf(buffer, "400 Command execution not supported\n");
      n = strlen(buffer);
      ret = sendn(connfd, buffer, n);
      if (ret < n) {
         perror("sendn");
      }
      goto cleanup;
   } 
   else 
   {
      /* command not supported */
      sprintf(buffer, "400 Command parsing error\n");
      n = strlen(buffer);
      ret = sendn(connfd, buffer, n);
      if (ret < n) 
      {
         perror("sendn");
      }
      goto cleanup;
   }

  //fprintf(stderr, "proc-exec.c: shell:\n<%s>\n", shell_path);

#ifdef linux
   exec_cmd(connfd, shell_path, "-c", cs, uid);  
#endif

   ret = 0;

cleanup:

   return ret;
}

#ifdef __NO__
/*
 * return -256 to indicate command not supported
 */

/* -------------------------------------------------------------------------
 * PARSE_COMMAND
 * -------------------------------------------------------------------------
 *
 */

int parse_command_line(const char *cmdline, struct cmd **cmdp)
{
  int i = -1;
  int n = -1;
  int ch = -1;
  int special_retval = 0;
  char tmpbuf[256] = {};

  struct cmd *tmpcmd = NULL;

  /* example command:
   * cat src.txt > file.out
   */
  int in_quote = 0;           /* are we inside '"' ? */
  int in_cmd = 0;             /* are we in the command [argv[0]] */
  int safe  = -1;             /* safe to ignore whitespace and exit from block */
  int in_input_redir = 0;     /* whether we are in input redirection file */
  int in_output_redir = 0;    /* whether we are in output redirection file */
  int pipe_started = 0;
  int arg0_found = 0;         /* for mapping of command */
  const char *argptr = NULL;

   safe = 0;                   /* is it safe to copy the temporary buffer and break from loop? */
   in_cmd = 1;                 /* we're at first in command [argv[0]] */
   n = 0;                      /* index for characters in tmpbuf */
   for (i = 0; ; i++) 
   {
      ch = cmdline[i];

      if (ch == '\0') 
      { // end of string
         /* command line ended but buffer not yet copied */
         if (in_input_redir) 
         {
            if (!in_quote) 
            {
               tmpbuf[n] = 0;
      //	  fprintf(stderr, "input redirection to %s\n", tmpbuf);
               cmd_add_iofile(tmpcmd, &tmpcmd->infile, tmpbuf);
               n = 0;
            }
            else
               n = -1;
         } 
         else if (in_output_redir) 
         {
            if (!in_quote) 
            {
               tmpbuf[n] = 0;
      //	  fprintf(stderr, "output redirection to %s\n", tmpbuf);
               cmd_add_iofile(tmpcmd, &tmpcmd->outfile, tmpbuf);
               n = 0;
            } 
            else 
               n = -1;
         } 
         else 
            n = 0;

         if (pipe_started == 0) 
            *cmdp = tmpcmd;
         else 
            cmd_add_pipe(*cmdp, tmpcmd);

         break;
      }

      if (in_cmd) 
      {

         /* by chance if the user doesn't put space before '<' or '>' */
         if ((ch == '<' || ch == '>') && !in_quote) 
         { /* input redirection */
            if (ch == '<') 
            {
               in_input_redir = 1;
               in_output_redir = 0;
            } 
            else 
            {
               in_output_redir = 1;
               in_input_redir = 0;
            }

            in_cmd = 0;
            tmpbuf[n] = 0;
      //	fprintf(stderr, "Adding vector: %s\n", tmpbuf);
            if (arg0_found == 0) 
            {
               arg0_found = 1;
               argptr = cmdmap_getmap(tmpbuf);
               if (!argptr) 
               { // command map not found
                  //fprintf(stderr, "debug: command not allowed: %s\n", tmpbuf);
                  if (special_retval == 0)
                  special_retval = CMD_NOSUPPORT;
                  // we don't allow this command to execute
                  //return -1;
                  argptr = tmpbuf;
               }
            } 
            else 
               argptr = tmpbuf;
            //fprintf(stderr, "<%s:%d> adding vector: <%s>\n", __FILE__,
            //    __LINE__, argptr);
            tmpcmd = cmd_add_vect(tmpcmd, argptr);
            n = 0;
            safe = 0;
            continue;
         } 
         else if (ch == ' ' || ch == '\t' || ch == '\n') 
         {
            if (in_quote) 
            { /* check whether we are in '"' */
               tmpbuf[n++] = ch; /* we allow whitespace in quote */
            } 
            else 
            { /* argument finished */
               if (safe) 
               { /* safe to exit from block */
                  tmpbuf[n] = 0;
      //	    fprintf(stderr, "Adding vector: %s\n", tmpbuf);
                  if (arg0_found == 0) 
                  {
                     arg0_found = 1;
                     argptr = cmdmap_getmap(tmpbuf);
                     if (!argptr) 
                     { // command map not found
                        //fprintf(stderr, "debug: command not allowed: %s\n", tmpbuf);
                        if (special_retval == 0)
                           special_retval = CMD_NOSUPPORT;
                        //return -1; /* returning here may cause memory leak */
                        argptr = tmpbuf;
                     }
                  } 
                  else 
                     argptr = tmpbuf;
                  //fprintf(stderr, "<%s:%d> adding vector: <%s>\n", __FILE__,
                     //__LINE__, argptr);
                  tmpcmd = cmd_add_vect(tmpcmd, argptr);
                  n = 0;
                  safe = 0;
               }
            }
         } 
         else if (ch == '|') 
         { // you _must_ have to put space b4 '|' in cmd
            if (pipe_started == 0) 
            {
               *cmdp = tmpcmd;
            } 
            else 
            {
      //	  fprintf(stderr, "Adding pipe <%d>\n", __LINE__);
               cmd_add_pipe(*cmdp, tmpcmd);
            }
            pipe_started = 1;
            tmpcmd = NULL;
            arg0_found = 0; // another arg0 will follow
         }  
         else 
         {
            tmpbuf[n++] = ch; /* nonblank character */
            safe = 1;
         }
      }

      else { /* redirection maybe */
         if (ch == '<') 
         {
            if (in_output_redir) 
            { /* we were already in output redir */
               if (in_quote) 
               { /* we were in quote, error */
                  return -1;
               } 
               else 
               { /* copy to redir_out */
                  if (safe) 
                  {
                     tmpbuf[n] = 0;
                     fprintf(stderr, "input redirection to %s\n", tmpbuf);
                     cmd_add_iofile(tmpcmd, &tmpcmd->infile, tmpbuf);
                  }
               }
            }
            in_input_redir = 1;
            in_output_redir = 0;
            n = 0;
            safe = 0;
            continue;
         } 
         else if (ch == '>') 
         {
            if (in_input_redir) 
            { /* we were already in output redir */
               if (in_quote) 
               { /* we were in quote, error */
                  return -1;
               } 
               else 
               { /* copy to redir_out */
                  if (safe) {
                     tmpbuf[n] = 0;
                     fprintf(stderr, "output redirection to %s\n", tmpbuf);
                     cm                  if (in_input_redir) {
                     tmpbuf[n] = 0;
                     fprintf(stderr, "input redirection to %s\n", tmpbuf);
                     cmd_add_iofile(tmpcmd, &tmpcmd->infile, tmpbuf);
                     in_input_redir = 0;
                  } else if (in_output_redir) {
                     tmpbuf[n] = 0;
                     fprintf(stderr, "output redirection to %s\n", tmpbuf);
                     cmd_add_iofile(tmpcmd, &tmpcmd->outfile, tmpbuf);
                     in_output_redir = 0;
                  }
                  n = 0;
                  safe = 0;d_add_iofile(tmpcmd, &tmpcmd->outfile, tmpbuf);
                  }
               }
            }
            in_input_redir = 0;
            in_output_redir = 1;
            n = 0;
            safe = 0;
            continue;
         }
   
         if (in_input_redir || in_output_redir) 
         {
            if (ch == '"') 
            { /* quote started or ended */
               if (!in_quote) 
               { /* quote started */
                  in_quote = 1;
                  safe = 0;
               } 
               else 
               { /* quote ended */
                  in_quote = 0;
                  if (in_input_redir) 
                  {
                     tmpbuf[n] = 0;
                     fprintf(stderr, "input redirection to %s\n", tmpbuf);
                     cmd_add_iofile(tmpcmd, &tmpcmd->infile, tmpbuf);
                     in_input_redir = 0; /* we are no longer in this section */
                  } 
                  else if (in_output_redir) 
                  {
                     tmpbuf[n] = 0;
                     fprintf(stderr, "output redirection to %s\n", tmpbuf);
                     cmd_add_iofile(tmpcmd, &tmpcmd->outfile, tmpbuf);
                     in_output_redir = 0; /* we are no longer in this section */
                  }
                  n = 0;
                  safe = 0;
               }
            } 
            else if (ch == ' ' || ch == '\t' || ch == '\n') 
            {
               if (in_quote) 
               { /* check whether we are in '"' */
                  tmpbuf[n++] = ch; /* we allow whitespace in quote */
               } 
               else 
               { /* argument finished */
                  if (safe) 
                  { /* safe to exit from block */
                     if (in_input_redir) 
                     {
                        tmpbuf[n] = 0;
                        fprintf(stderr, "input redirection to %s\n", tmpbuf);
                        cmd_add_iofile(tmpcmd, &tmpcmd->infile, tmpbuf);
                        in_input_redir = 0;
                     } 
                     else if (in_output_redir) 
                     {
                        tmpbuf[n] = 0;
                        fprintf(stderr, "output redirection to %s\n", tmpbuf);
                        cmd_add_iofile(tmpcmd, &tmpcmd->outfile, tmpbuf);
                        in_output_redir = 0;
                     }
                     n = 0;
                     safe = 0;
                  }
               }
            } 
            else 
            {
               tmpbuf[n++] = ch; /* nonblank character */
               safe = 1;
            }
         }
      }
  }

  if (special_retval != 0)
    return special_retval;

  return n;
}
#endif

/*
 * return -256 to indicate command not supported
 */

/* -------------------------------------------------------------------------
 * FIX_COMMAND
 * -------------------------------------------------------------------------
 *
 */

int fix_command_line(const char *cmdline, char *cmdp)
{
   int i = 0;
   int j = 0;
   int ch = 0;
   int special_retval = 0;
   int find_map = 1; // map finding should be started
   int safe = 0;
   
   char tmpbuf[256] = {};
   const char *ptr = NULL;

   i = j = 0;
   while (1) 
   {
      ch = *cmdline++;
      
      if (find_map) 
      {
         if (ch == ' ' || ch == '\t' || ch == '\n' || ch == '\0') 
         {
            if (safe) 
            {
               tmpbuf[j] = '\0';
         
               ptr = cmdmap_getmap(tmpbuf);
               if (!ptr) 
               {
                  special_retval = CMD_NOSUPPORT;
                  break;
               }
               j = strlen(ptr);
               memcpy(cmdp+i, ptr, j); // strncat
               i += j;
               cmdp[i++] = ch; // append the current character read
               j = 0;
               find_map = 0;
               safe = 0;
            } 
            else 
            { // not safe
               cmdp[i++] = ch;
            }
         } 
         else 
         {
            tmpbuf[j++] = ch;
            safe = 1;
         }
      } 
      else  
      {
         cmdp[i++] = ch;
      }
      
      if (ch == '\0') 
      {
         break;
      } 
      else if (ch == '|')
      {
         find_map = 1; // next command should be searched for mapping
      }
   }

   if (cmdp[i-2] == '\n') 
   { // -2 is because we copied '\0' too
      cmdp[i-2] = '\0';
   }

   if (special_retval != 0)
      return special_retval;

  return 0;
}

#ifdef linux
//static int auth_success = 0;

/* -------------------------------------------------------------------------
 * AUTHENTICATE_CLIENT
 * -------------------------------------------------------------------------
 *
 */

int authenticate_client(int connfd, char *shell, uid_t *uid)
{
//  fprintf(stderr, "<%s>\n", __func__);

   int ret = -1;
   char buffer[100] = {};
   struct passwd *pw;
   int n = -1;
   char username[40] = {};
   char password[40] = {};
   
   sprintf(buffer, "300 Login: \n");
   n = strlen(buffer);
   ret = sendn(connfd, buffer, n);

   if (ret < n) 
   {
      DEBUG("sendn", errno);
      ret = -1;
      goto cleanup;
   }

   n = recvline(connfd, buffer, sizeof(buffer));

   if (buffer[n-1] == '\n')
      buffer[n-1] = 0; /* disard newline */

   strcpy(username, buffer);

   /* hold a lock to read the password entry, this is to save some memory */
   pthread_mutex_lock(&pwlock);

   pw = getpwnam(username);
   if (!pw) 
   { /* no such user */
      pthread_mutex_unlock(&pwlock);
      sprintf(buffer, "200 No such user '%s'!\n", username);
      n = strlen(buffer);
      sendn(connfd, buffer, n);
      ret = -1;
      goto cleanup;
   }
   *uid = pw->pw_uid;
   strcpy(shell, pw->pw_shell);

   pthread_mutex_unlock(&pwlock);
   
   sprintf(buffer, "350 Password: \n");
   n = strlen(buffer);
   ret = sendn(connfd, buffer, n);
   if (ret < n) 
   {
      DEBUG("sendn", errno);
      ret = -1;
      goto cleanup;
   }
   
   n = recvline(connfd, buffer, sizeof(buffer));
   //  if (buffer[n-1] == '\n')
   //    buffer[n-1] = 0; /* disard newline */
   strcpy(password, buffer);
   
   int status = -1;
   pid_t pid;
   int pipes[2];
   
   if (pipe(pipes) != 0) 
   {
      perror("pipe");
      ret = -1;
      goto cleanup;
   }

   switch ((pid = fork())) 
   {
      case -1:
         perror("fork");
         ret = -1;
         goto cleanup;
         break;
      case 0: /* child */
         close(connfd);
         close(pipes[1]);
         dup2(pipes[0], fileno(stdin)); /* now stdin is pipes[0] */
         close(pipes[0]);
         ret = authenticate(connfd, username, "rlogin");
         // the PAM login system is not working, so for now making always
         // success
         ret = 0; // just for testing provided that login is OK
   //      write(pipes[1], &ret, sizeof(ret));
   //      fprintf(stderr, "Child: exiting [%d]\n", ret);
         exit(ret);
         break;
      default: /* parent */
         close(pipes[0]);
         /*
         if (password[n-1] != '\n') {
         password[n] = '\n';
         password[n+1] = '\0';
         n++;
         }
         */
         write(pipes[1], password, n);
         waitpid(pid, &status, 0);
         close(pipes[1]);
         ret = WEXITSTATUS(status);
   //      fprintf(stderr, "Parent: child exit status %d\n", ret);
         if (ret == 0) 
         {
            sprintf(buffer, "100 Login Successful!\n");
            n = strlen(buffer);
            ret = sendn(connfd, buffer, n);
            ret = 0;
         } 
         else 
         {
            sprintf(buffer, "200 Login Failure!\n");
            n = strlen(buffer);
            ret = sendn(connfd, buffer, n);
            ret = -1;
         }
         break;
   }

cleanup:
   return ret;
}

#endif /* linux */


#ifdef __NO__
/* simple command line parser */

/* -------------------------------------------------------------------------
 * PARSE_COMMAND
 * -------------------------------------------------------------------------
 *
 */

int parse_command_line(const char *line, struct cmd **cmdp)
{
   //  fprintf(stderr, "<%s>\n", __func__);
   /*
   size_t size;
   size_t len;
   const char *ptr1;
   */
   char cmdbuf[256] = {};
   
   char *str1 = NULL;
   char *str2 = NULL;
   char *token = NULL;
   char *subtoken = NULL;
   char *saveptr1 = NULL; 
   char *saveptr2  = NULL;
   int i = 0
   int j = 0;
   
   int redirect_output = 0;
   int redirect_input = 0;

   //  struct cmd *cmdp = NULL;
   struct cmd *tmpcmd = NULL;
   
   //  fprintf(stderr, "%s\n", line);

   strcpy(cmdbuf, line);
   i = strlen(cmdbuf);

   if (cmdbuf[i-1] == '\n')
      cmdbuf[i-1] = 0;
   for (i = 0, str1 = cmdbuf; ; i++, str1 = NULL) 
   {
      token = strtok_r(str1, "|", &saveptr1);
      if (token == NULL)
         break;

      tmpcmd = NULL;
      for (j = 0, str2 = token; ; j++, str2 = NULL) 
      {
         subtoken = strtok_r(str2, " ", &saveptr2);
         if (subtoken == NULL)
            break;
         if (!strcmp(subtoken, ">")) 
         {
            redirect_output = 1;
            continue;
         } 
         else if (!strcmp(subtoken, "<")) 
         {
            redirect_input = 1;
            continue;
         }
         if (redirect_output && redirect_input) 
         {
   //	fprintf(stderr, "Ambiguous redirection\n");
         } 
         else if (redirect_output) 
         {
            cmd_add_iofile(tmpcmd, &tmpcmd->outfile, subtoken);
            redirect_output = 0;
      //	fprintf(stderr, "Output redirects to %s\n", tmpcmd->outfile);
            continue; /* don't add this to argument list */
         } 
         else if (redirect_input) 
         {
            cmd_add_iofile(tmpcmd, &tmpcmd->infile, subtoken);
            redirect_input = 0;
      //	fprintf(stderr, "Input redirects to %s\n", tmpcmd->infile);
            continue; /* don't add this to argument list */
         }
   
   //      fprintf(stderr, "argv[%d][%d] = %s\n", i, j, subtoken);
         tmpcmd = cmd_add_vect(tmpcmd, subtoken);
      }
      if (i == 0) 
      {
         *cmdp = tmpcmd;
      } 
      else 
      {
   //      fprintf(stderr, "Adding pipe\n");
         cmd_add_pipe(*cmdp, tmpcmd);
      }
   }
   
   return 0;
}
#endif


