
#include "server-funcs.h"

/* 500 means success */
/* please read error-codes.txt for values used in protocol */

/* please read 'protocol.txt' for understanding the protocol used */
/* handle download */

/* -------------------------------------------------------------------------
 * PROC_DOWNLOAD
 * -------------------------------------------------------------------------
 *
 */
int proc_download(int connfd, const char *buf)
{
   int fd = -1;
   int ret = -1;
   size_t n = -1;
   size_t len = -1;
   char comd[10] = {};
   char file[256] = {};
   char buffer[1024] = {};
   int del = -1;

   struct stat statbuf;

   /* COPY|MOVE file:del */
   sscanf(buf, "%s", comd);     /* comd = COPY|MOVE */
   len = strlen(comd);
   len++;                       /* skip the <space> */
   n = strcspn(buf+len, DELIM); /* DELIM is #define'd in common.h */

   strncpy(file, buf+len, n);
   file[n] = '\0';               /* insert string delimiter */
   del = *(buf+len + n + 1) - '0';
   printf("<%s:%d> file=<%s> del=<%d>\n", __FILE__, __LINE__, file, del);

   memset(&statbuf, 0, sizeof(statbuf));
   
   if (stat(file, &statbuf) != 0) 
   {
      perror("stat");
      sprintf(buffer, "server: stat: %s: %s\n", file, strerror(errno));
      sendn(connfd, buffer, strlen(buffer));
      return -1;
   }

   if ((fd = open(file, O_RDONLY)) < 0) 
   {
      perror("open");
      sprintf(buffer, "400 ERROR server: open: %s\n", strerror(errno));
      sendn(connfd, buffer, strlen(buffer));
      goto cleanup;
   }

   if (del == 0)
      ret = flock(fd, LOCK_SH); /* get shared [read] lock */
   else
      ret = flock(fd, LOCK_EX); /* get exclusive [write] lock */

   if (ret == -1) 
   {  /* error */
      perror("flock");
      sprintf(buffer, "400 ERROR server: flock: %s\n", strerror(errno));
      sendn(connfd, buffer, strlen(buffer));
      flock(fd, LOCK_UN);  /* unlock the file */
      goto cleanup;
   }

   if (stat(file, &statbuf) != 0) 
   {
      perror("stat");
      sprintf(buffer, "File is removed before the processing of your request\n");
      sendn(connfd, buffer, strlen(buffer));
      flock(fd, LOCK_UN);  /* unlock the file */
      close(fd);
      return -1;
   }

   /* inform client that we've opened [and locked] the file successfully */
   sprintf(buffer, "500 OK %d\n", (int) statbuf.st_size);
   n = strlen(buffer);
   ret = sendn(connfd, buffer, n);

   if (ret < n) 
   {
      DEBUG("sendn", errno);
      flock(fd, LOCK_UN);  /* unlock the file */
      goto cleanup;
   }

   while ((n = read(fd, buffer, sizeof(buffer))) > 0) 
   {
      ret = sendn(connfd, buffer, n);
   
      if (ret < 0) 
      {
         DEBUG("sendn", errno);
         flock(fd, LOCK_UN);  /* unlock the file */
         goto cleanup;
      }
   }

   if (del == 0)
      flock(fd, LOCK_UN);  /* unlock the file */
   
   ret = 0; /* all it's ok */

/* -------------------------------------------------------------------------
 * CLEAN-UP
 * -------------------------------------------------------------------------
 *
 */

cleanup:
  /* release read-lock here */

  /* if successful, delete the file if 'del' is TRUE */
   if (ret == 0 && del == 1) 
   {
      if (remove(file) != 0) 
      {
         perror("remove");
         sprintf(buffer, "400 ERROR: remove: %s\n", strerror(errno));
         n = strlen(buffer);
         ret = sendn(connfd, buffer, n);
         flock(fd, LOCK_UN);  /* unlock the file */
         
         if (ret < n) 
         DEBUG("sendn", errno); 
      }
   }
      
   if (fd > 0) 
      close(fd);
   
   return ret;
}

