If you are in this directory, type in command line:

[in Linux]
make
[in Windows [Cygwin Environment]]
make -f Makefile.cygwin

Executables:
Server: server [linux]
        server.exe [Windows]
Client: shell [linux]
        shell.exe [Windows]

See 'COMMANDS.TXT' file for supported commands and their syntax.
See 'AUTHORS' file for Author Information
You can modify the Makefile[.cygwin] as your need.

		Thanks
		Ayub
		Techno Villa
