/*
 * proc-upload.c
 */
#include "server-funcs.h"

/* 500 means success */
/* please read error-codes.txt for values used in protocol */

static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

/* please read 'protocol.txt' for understanding the protocol used */
/* handle file upload */

/* -------------------------------------------------------------------------
 * PROC_UPLOAD
 * -------------------------------------------------------------------------
 *
 */

int proc_upload(int connfd, const char *buf)
{
   int fd = -1;
   int ret = -1;
   int n = -1;
   mode_t mode = 00644;
   char comd[10] = {};
   char file[256] = {};
   char buffer[1024] = {};

   sscanf(buf, "%s %[^\n]", comd, file);
   printf("<%s:%d> file=<%s>\n", __FILE__, __LINE__, file);
   
   /* to prevent race condition hold the mutex here */
   pthread_mutex_lock(&mutex);
   
   /* the lock is held before checking the existance of the file, so no race
   * condition will arise
   */
   if (access(file, F_OK) == 0) 
   {
      DEBUG("Output file exists!", 0);
      sprintf(buffer, "server: Output file exists!\n");
      n = strlen(buffer);
      ret = sendn(connfd, buffer, n);
      pthread_mutex_unlock(&mutex);
      return 0;
   }

  /* create file for writing */
   if ((fd = open(file, O_CREAT|O_TRUNC|O_WRONLY, mode)) < 0) 
   {
      perror("open");
      sprintf(buffer, "server: open: %s\n", strerror(errno));
      sendn(connfd, buffer, strlen(buffer));
      pthread_mutex_unlock(&mutex);
      goto cleanup;
   }
   
   ret = flock(fd, LOCK_EX); /* get exclusive [write] lock */

   if (ret == -1) 
   { // error
      perror("flock");
      sprintf(buffer, "400 ERROR server: flock: %s\n", strerror(errno));
      sendn(connfd, buffer, strlen(buffer));
      pthread_mutex_unlock(&mutex);
      goto cleanup;
   }

   /* hold a write-lock here */
   /* write lock will prevent readers [proc-download.c] from reading while this
   * thread is writing
   */
   
   /*
   if ((ret = pthread_rwlock_wrlock(&rwlock)) != 0) 
   {
      fprintf(stderr, "pthread_rwlock_wlock: %s\n", strerror(ret));
      return -1;
   }
   */
      
   /* file is now created and the creator thread have an  EX_lock on it, 
    * other threads will now see the file by access(), and wait a lock on it */
   /* so we can unlock the mutex here */
   pthread_mutex_unlock(&mutex);

   sprintf(buffer, "500 OK\n");
   n = strlen(buffer);
   ret = sendn(connfd, buffer, n);
   if (ret < n) 
   {
      DEBUG("sendn", errno);
      flock(fd, LOCK_UN); /* unlock the file */
      goto cleanup;
   }

   /* get the file from client and write to file */
   while ((n = recv(connfd, buffer, sizeof(buffer), 0)) > 0) 
   {
      ret = write(fd, buffer, n);
      if (ret < 0) 
      {
         perror("write");
         sprintf(buffer, "server: write: %s\n", strerror(errno));
         n = strlen(buffer);
         ret = sendn(connfd, buffer, n);
         flock(fd, LOCK_UN); // unlock the file
         goto cleanup;
      }
   }

   flock(fd, LOCK_UN); // unlock the file
   
   ret = 0;
   
/* -------------------------------------------------------------------------
 * CLEAN-UP
 * -------------------------------------------------------------------------
 *
 */
cleanup:
   if (fd > 0) 
      close(fd);
   
   /* release the write-lock here */
   /*
   pthread_rwlock_unlock(&rwlock);
   */
   return ret;
}

