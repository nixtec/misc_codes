/* mutex for modify in mutual exclusion globalR and globalW variables */
pthread_mutex_t mGlobalRW = PTHREAD_MUTEX_INITIALIZER;

/*mutex for modify in mutual exclusion curR variable*/
pthread_mutex_t mCurR = PTHREAD_MUTEX_INITIALIZER;

/*mutex for modify in mutual exclusion curW variable*/
pthread_mutex_t mCurW = PTHREAD_MUTEX_INITIALIZER;


/* condition variable that represent the permission to "read" a file 
 * (simple copy of a file) 
 */
pthread_cond_t condR = PTHREAD_COND_INITIALIZER;

/* condition variable that represent the permission to "write" a file
* (creation/removal/moving a file)
*/
pthread_cond_t condW = PTHREAD_COND_INITIALIZER;

int globalR = 0;  /* total number of reader threads */
int globalW = 0;  /* total number of writer threads */
int curR = 0;     /* number of reader threads that currently are reading */
int curW = 0;     /* number of writer threads that currently are writing */
