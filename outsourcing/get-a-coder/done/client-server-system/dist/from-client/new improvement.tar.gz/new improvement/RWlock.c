int readerStart()
{
   pthread_mutex_lock(&mGlobalRW); 
	++globalR;                      /* update the global number of reader thread */
	if( globalW > 0 )
		pthread_cond_wait(&condR, &mGlobalRW);   /* stop reader threads to satisfy writer threads request */
		
   pthread_mutex_unlock(&mGlobalRW);
		
   pthread_mutex_lock(&mCurR);
   ++curR;                         /* update the current number of active reader thread */
   pthread_mutex_unlock(&mCurR);
}   

int readerEnd()
{   
   /* this thread has finished reading */
   pthread_mutex_lock(&mCurR);   	
   --curR;                         /* update the current number of active reader thread */
   pthread_mutex_lock(&mGlobalRW); 
   --globaR;                       /* update the global number of reader thread */
   
   pthread_mutex_unlock(&mGlobalRW);
   	if( curR == 0)                        /* if there are no more "active" readers..*/
   		pthread_cond_broadcast (&condW);   /* ..waiting writers can do their work */
   		
   pthread_mutex_unlock(&mCurR);
}

int writerStart()
{
   pthread_mutex_lock(&mGlobalRW);
	++globalW;                      /* update the global number of writer thread */
	if( globalR > 0 )
		pthread_cond_wait(&condW, &mGlobalRW);
		
	pthread_mutex_unlock(&mGlobalRW);
		
   pthread_mutex_lock(&mCurW);
   ++curW;                          /* update the current number of active writer thread */
   pthread_mutex_unlock(&mCurW);
}

int writerEnd(){   
   pthread_mutex_lock(&mCurW);   	
   --curW;                          /* update the current number of active writer thread */
   pthread_mutex_lock(&mGlobalRW); 
   --globaW;                        /* update the global number of writer thread */
   
   pthread_mutex_unlock(&mGlobalRW);
   	if( curW == 0)                        /* if there are no more "active" writers..*/
   		pthread_cond_broadcast(&condR);    /* ..waiting readers can do their work */
   		
   pthread_mutex_unlock(&mCurW);
}
