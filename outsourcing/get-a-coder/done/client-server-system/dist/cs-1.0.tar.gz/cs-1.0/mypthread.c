/*
 * mypthread.c
 */

#include "pthread_create.c"
#include "pthread_detach.c"
#include "pthread_exit.c"

