/*
 * pthread.c
 */

/* compile only in Windows */

#ifdef __WIN32__

#include "mypthread.c"
#include "mymutex.c"
#include "mycond.c"
#include "myrwlock.c"


#endif
