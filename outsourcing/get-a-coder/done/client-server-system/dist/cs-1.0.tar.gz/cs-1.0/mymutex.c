/*
 * mymutex.c
 */

#include "pthread_mutex_init.c"
#include "pthread_mutex_lock.c"
#include "pthread_mutex_unlock.c"
#include "pthread_mutex_destroy.c"

