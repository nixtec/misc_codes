/*
 * myrwlock.c
 */
#include "mypthread.h"

#include "pthread_rwlock_destroy.c"
#include "pthread_rwlock_init.c"
#include "pthread_rwlock_rdlock.c"
#include "pthread_rwlock_tryrdlock.c"
#include "pthread_rwlock_trywrlock.c"
#include "pthread_rwlock_unlock.c"
#include "pthread_rwlock_wrlock.c"
